
<div class="va">
    <div class="content">
        <div class="L">
            <div class="title">
                Проект             </div>
            <div class=".content">
                <img src="http://plans.ru/images/projects/.jpg" alt=""/>
            </div>
        </div>
        <div class="R">
            <div class="close" data-dismiss="modal"></div>

            <h4>Консультация<br/>Архитектора СТРОЙФОНД</h4>

            <p class="cl">Введите Ваше имя и телефон.<br/>
                Архитектор компании СТРОЙФОНД свяжется<br/>
                с Вами для консультации.</p>

            <form action="" class="modal_about sender" method="post">
                <input type="hidden" name="form-name" value="Plans.ru / Проект ">
                <input type="hidden" name="form-type" value="callback">

                <div class="inp">
                    <p>Введите Ваше имя</p>
                    <input name="name" placeholder="Иван Иванов" type="text"/></div>
                <div class="inp ph">
                    <p>Введите Ваш телефон</p>
                    <input name="phone" required pattern="^((8|\+7)[\- ]?)?(\(?\d{3}\)?[\- ]?)?[\d\- ]{7,10}$"
                           placeholder="+7 (123) 123-12-34" type="text"/>
                    <div class="clear"></div>
                </div>
                <button class="bttn" type="submit">Рассчитать смету</button>
                <div class="clear"></div>
            </form>

            <p class="cl"><br/>или позвоните нам по телефону<br/>
                <b class="comagic_phone phone" style="font-size: 26px;">+7 (495) 374-66-40</b>
            </p>
        </div>
        <div class="clear"></div>
    </div>
</div>
